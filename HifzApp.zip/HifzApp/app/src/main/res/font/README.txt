# Font directory
# Download Amiri font from https://fonts.google.com/specimen/Amiri
# Place amiri_regular.ttf here as amiri.ttf
# Then reference it in themes.xml as @font/amiri
