package com.hifz.app.utils;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Log;
import java.io.*;

public class AudioRecorder {

    private static final String TAG = "AudioRecorder";
    private static final int SAMPLE_RATE = 16000;
    private static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;

    private AudioRecord audioRecord;
    private boolean isRecording = false;
    private Thread recordingThread;
    private File outputFile;

    public interface RecordingCallback {
        void onAmplitudeChanged(int amplitude);
        void onRecordingComplete(File file);
        void onError(String error);
    }

    private RecordingCallback callback;

    public AudioRecorder(File outputFile, RecordingCallback callback) {
        this.outputFile = outputFile;
        this.callback = callback;
    }

    public void startRecording() {
        int bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);

        audioRecord = new AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT, bufferSize * 2);

        if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
            callback.onError("Failed to initialize AudioRecord");
            return;
        }

        isRecording = true;
        audioRecord.startRecording();

        recordingThread = new Thread(() -> {
            writeAudioToFile(bufferSize);
        });
        recordingThread.start();
    }

    private void writeAudioToFile(int bufferSize) {
        byte[] data = new byte[bufferSize];
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        while (isRecording) {
            int read = audioRecord.read(data, 0, data.length);
            if (read > 0) {
                baos.write(data, 0, read);

                // Calculate amplitude for visualization
                int amplitude = 0;
                for (int i = 0; i < read - 1; i += 2) {
                    short sample = (short) ((data[i + 1] << 8) | data[i]);
                    amplitude = Math.max(amplitude, Math.abs(sample));
                }
                final int amp = amplitude;
                if (callback != null) {
                    callback.onAmplitudeChanged(amp);
                }
            }
        }

        // Write WAV file
        try {
            writeWavFile(baos.toByteArray(), outputFile);
            callback.onRecordingComplete(outputFile);
        } catch (IOException e) {
            callback.onError("Failed to save recording: " + e.getMessage());
        }
    }

    public void stopRecording() {
        isRecording = false;
        if (audioRecord != null) {
            audioRecord.stop();
            audioRecord.release();
            audioRecord = null;
        }
    }

    private void writeWavFile(byte[] pcmData, File output) throws IOException {
        int dataSize = pcmData.length;
        int totalSize = dataSize + 36;

        try (FileOutputStream fos = new FileOutputStream(output);
             DataOutputStream dos = new DataOutputStream(fos)) {

            // RIFF header
            dos.writeBytes("RIFF");
            writeInt(dos, totalSize);
            dos.writeBytes("WAVE");

            // fmt chunk
            dos.writeBytes("fmt ");
            writeInt(dos, 16);
            writeShort(dos, (short) 1);  // PCM
            writeShort(dos, (short) 1);  // Mono
            writeInt(dos, SAMPLE_RATE);
            writeInt(dos, SAMPLE_RATE * 2); // ByteRate
            writeShort(dos, (short) 2);  // BlockAlign
            writeShort(dos, (short) 16); // BitsPerSample

            // data chunk
            dos.writeBytes("data");
            writeInt(dos, dataSize);
            dos.write(pcmData);
        }
    }

    private void writeInt(DataOutputStream dos, int value) throws IOException {
        dos.write(value & 0xFF);
        dos.write((value >> 8) & 0xFF);
        dos.write((value >> 16) & 0xFF);
        dos.write((value >> 24) & 0xFF);
    }

    private void writeShort(DataOutputStream dos, short value) throws IOException {
        dos.write(value & 0xFF);
        dos.write((value >> 8) & 0xFF);
    }

    public boolean isRecording() {
        return isRecording;
    }
}
