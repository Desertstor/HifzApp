package com.hifz.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.hifz.app.R;
import com.hifz.app.data.Surah;
import java.util.ArrayList;
import java.util.List;

public class SurahListActivity extends AppCompatActivity {

    private HifzViewModel viewModel;
    private SurahAdapter adapter;
    private List<Surah> allSurahs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Simple layout built programmatically
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF5F5F0);

        MaterialToolbar toolbar = new MaterialToolbar(this);
        toolbar.setTitle("Select Surah");
        toolbar.setTitleTextColor(0xFFFFD700);
        toolbar.setBackgroundColor(0xFF1B5E20);
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationIconTint(0xFFFFFFFF);
        toolbar.setNavigationOnClickListener(v -> finish());
        root.addView(toolbar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Search box
        TextInputEditText searchBox = new TextInputEditText(this);
        searchBox.setHint("Search surah...");
        searchBox.setBackgroundColor(0xFFFFFFFF);
        searchBox.setPadding(48, 24, 48, 24);
        root.addView(searchBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        RecyclerView recyclerView = new RecyclerView(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setPadding(0, 8, 0, 8);
        root.addView(recyclerView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);

        viewModel = new ViewModelProvider(this).get(HifzViewModel.class);
        adapter = new SurahAdapter(surah -> {
            viewModel.updateSurahStatus(surah.number, 1); // Mark as in-progress
            Intent intent = new Intent(this, RecitationActivity.class);
            intent.putExtra("surah_number", surah.number);
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        viewModel.getAllSurahs().observe(this, surahs -> {
            allSurahs = surahs;
            adapter.submitList(new ArrayList<>(surahs));
        });

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String query = s.toString().toLowerCase().trim();
                List<Surah> filtered = new ArrayList<>();
                for (Surah surah : allSurahs) {
                    if (surah.nameArabic.contains(query) ||
                            surah.nameEnglish.toLowerCase().contains(query) ||
                            surah.nameTransliteration.toLowerCase().contains(query) ||
                            String.valueOf(surah.number).contains(query)) {
                        filtered.add(surah);
                    }
                }
                adapter.submitList(filtered);
            }
        });
    }
}
