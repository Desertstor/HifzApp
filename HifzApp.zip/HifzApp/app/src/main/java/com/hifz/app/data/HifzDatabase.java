package com.hifz.app.data;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Surah.class, Ayah.class}, version = 1, exportSchema = false)
public abstract class HifzDatabase extends RoomDatabase {

    public abstract SurahDao surahDao();
    public abstract AyahDao ayahDao();

    private static volatile HifzDatabase INSTANCE;
    static final ExecutorService executor = Executors.newFixedThreadPool(4);

    public static HifzDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (HifzDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    HifzDatabase.class,
                                    "hifz_database")
                            .addCallback(new RoomDatabase.Callback() {
                                @Override
                                public void onCreate(SupportSQLiteDatabase db) {
                                    super.onCreate(db);
                                    executor.execute(() -> {
                                        HifzDatabase database = getInstance(context);
                                        database.surahDao().insertAll(SurahData.getAllSurahs());
                                    });
                                }
                            })
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
