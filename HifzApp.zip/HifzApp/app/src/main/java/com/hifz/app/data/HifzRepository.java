package com.hifz.app.data;

import android.app.Application;
import androidx.lifecycle.LiveData;
import java.util.List;

public class HifzRepository {

    private final SurahDao surahDao;
    private final AyahDao ayahDao;

    private final LiveData<List<Surah>> allSurahs;
    private final LiveData<List<Surah>> inProgressSurahs;
    private final LiveData<Integer> memorizedCount;
    private final LiveData<Integer> totalMemorizedAyahs;

    public HifzRepository(Application application) {
        HifzDatabase db = HifzDatabase.getInstance(application);
        surahDao = db.surahDao();
        ayahDao = db.ayahDao();
        allSurahs = surahDao.getAllSurahs();
        inProgressSurahs = surahDao.getInProgressSurahs();
        memorizedCount = surahDao.getMemorizedCount();
        totalMemorizedAyahs = surahDao.getTotalMemorizedAyahs();
    }

    public LiveData<List<Surah>> getAllSurahs() { return allSurahs; }
    public LiveData<List<Surah>> getInProgressSurahs() { return inProgressSurahs; }
    public LiveData<Integer> getMemorizedCount() { return memorizedCount; }
    public LiveData<Integer> getTotalMemorizedAyahs() { return totalMemorizedAyahs; }

    public LiveData<Surah> getSurah(int number) {
        return surahDao.getSurah(number);
    }

    public LiveData<List<Ayah>> getAyahsForSurah(int surahNumber) {
        return ayahDao.getAyahsForSurah(surahNumber);
    }

    public void updateSurahStatus(int number, int status) {
        HifzDatabase.executor.execute(() -> {
            surahDao.updateStatus(number, status, System.currentTimeMillis());
        });
    }

    public void recordCorrectRecitation(int surahNumber, int ayahNumber) {
        HifzDatabase.executor.execute(() -> {
            ayahDao.recordCorrect(surahNumber, ayahNumber, System.currentTimeMillis());
            surahDao.incrementPracticeCount(surahNumber, System.currentTimeMillis());
            int memorized = ayahDao.getMemorizedCount(surahNumber);
            surahDao.updateMemorizedAyahs(surahNumber, memorized);
        });
    }

    public void recordMistake(int surahNumber, int ayahNumber) {
        HifzDatabase.executor.execute(() -> {
            ayahDao.recordMistake(surahNumber, ayahNumber);
        });
    }

    public void setAyahMemorized(int surahNumber, int ayahNumber, boolean memorized) {
        HifzDatabase.executor.execute(() -> {
            ayahDao.setMemorized(surahNumber, ayahNumber, memorized);
            int count = ayahDao.getMemorizedCount(surahNumber);
            surahDao.updateMemorizedAyahs(surahNumber, count);
        });
    }

    public LiveData<List<Ayah>> getDifficultAyahs() {
        return ayahDao.getDifficultAyahs();
    }
}
