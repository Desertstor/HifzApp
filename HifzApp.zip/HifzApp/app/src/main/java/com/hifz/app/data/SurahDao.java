package com.hifz.app.data;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import java.util.List;

@Dao
public interface SurahDao {

    @Query("SELECT * FROM surahs ORDER BY number")
    LiveData<List<Surah>> getAllSurahs();

    @Query("SELECT * FROM surahs WHERE number = :number")
    LiveData<Surah> getSurah(int number);

    @Query("SELECT * FROM surahs WHERE hifzStatus = 1 ORDER BY lastPracticed DESC")
    LiveData<List<Surah>> getInProgressSurahs();

    @Query("SELECT * FROM surahs WHERE hifzStatus = 2")
    LiveData<List<Surah>> getMemorizedSurahs();

    @Query("SELECT COUNT(*) FROM surahs WHERE hifzStatus = 2")
    LiveData<Integer> getMemorizedCount();

    @Query("SELECT SUM(memorizedAyahs) FROM surahs")
    LiveData<Integer> getTotalMemorizedAyahs();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Surah> surahs);

    @Update
    void update(Surah surah);

    @Query("UPDATE surahs SET hifzStatus = :status, lastPracticed = :time WHERE number = :number")
    void updateStatus(int number, int status, long time);

    @Query("UPDATE surahs SET memorizedAyahs = :count WHERE number = :number")
    void updateMemorizedAyahs(int number, int count);

    @Query("UPDATE surahs SET practiceCount = practiceCount + 1, lastPracticed = :time WHERE number = :number")
    void incrementPracticeCount(int number, long time);
}
