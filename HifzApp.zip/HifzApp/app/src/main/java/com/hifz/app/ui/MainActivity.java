package com.hifz.app.ui;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.hifz.app.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private HifzViewModel viewModel;
    private SurahAdapter inProgressAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);

        viewModel = new ViewModelProvider(this).get(HifzViewModel.class);

        setupRecyclerView();
        observeData();
        setupClickListeners();
    }

    private void setupRecyclerView() {
        inProgressAdapter = new SurahAdapter(surah -> {
            Intent intent = new Intent(this, RecitationActivity.class);
            intent.putExtra("surah_number", surah.number);
            startActivity(intent);
        });
        binding.rvInProgress.setLayoutManager(new LinearLayoutManager(this));
        binding.rvInProgress.setAdapter(inProgressAdapter);
    }

    private void observeData() {
        viewModel.getMemorizedCount().observe(this, count -> {
            int c = count != null ? count : 0;
            binding.tvMemorizedSurahs.setText(String.valueOf(c));
            int progress = (c * 100) / 114;
            binding.progressOverall.setProgress(progress);
            binding.tvProgressPercent.setText(progress + "% of Quran memorized (" + c + "/114 Surahs)");
        });

        viewModel.getTotalMemorizedAyahs().observe(this, ayahs -> {
            int a = ayahs != null ? ayahs : 0;
            binding.tvMemorizedAyahs.setText(String.valueOf(a));
        });

        viewModel.getInProgressSurahs().observe(this, surahs -> {
            inProgressAdapter.submitList(surahs);
        });
    }

    private void setupClickListeners() {
        binding.btnSelectSurah.setOnClickListener(v -> {
            startActivity(new Intent(this, SurahListActivity.class));
        });

        binding.btnViewProgress.setOnClickListener(v -> {
            startActivity(new Intent(this, HifzProgressActivity.class));
        });

        binding.fabRecite.setOnClickListener(v -> {
            startActivity(new Intent(this, SurahListActivity.class));
        });
    }
}
