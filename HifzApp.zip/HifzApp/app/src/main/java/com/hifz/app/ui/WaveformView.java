package com.hifz.app.ui;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;
import java.util.LinkedList;
import java.util.Queue;

public class WaveformView extends View {

    private final Paint wavePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Queue<Integer> amplitudes = new LinkedList<>();
    private boolean isAnimating = false;
    private static final int MAX_BARS = 40;

    public WaveformView(Context context, AttributeSet attrs) {
        super(context, attrs);
        wavePaint.setColor(Color.parseColor("#1B5E20"));
        wavePaint.setStrokeWidth(6f);
        wavePaint.setStrokeCap(Paint.Cap.ROUND);
        bgPaint.setColor(Color.parseColor("#F0F0F0"));
    }

    public void startAnimation() {
        isAnimating = true;
        amplitudes.clear();
        invalidate();
    }

    public void stopAnimation() {
        isAnimating = false;
        amplitudes.clear();
        invalidate();
    }

    public void updateAmplitude(int amplitude) {
        if (amplitudes.size() >= MAX_BARS) {
            amplitudes.poll();
        }
        amplitudes.add(amplitude);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        int centerY = height / 2;

        // Background
        canvas.drawRoundRect(0, 0, width, height, 8, 8, bgPaint);

        if (!isAnimating || amplitudes.isEmpty()) {
            // Draw flat line
            wavePaint.setAlpha(80);
            canvas.drawLine(0, centerY, width, centerY, wavePaint);
            return;
        }

        wavePaint.setAlpha(255);
        int barWidth = width / MAX_BARS;
        int[] amps = amplitudes.stream().mapToInt(i -> i).toArray();
        int maxAmp = 32768;

        for (int i = 0; i < amps.length; i++) {
            float normalizedAmp = (float) amps[i] / maxAmp;
            float barHeight = Math.max(4, normalizedAmp * centerY * 0.9f);
            float x = i * barWidth + barWidth / 2f;

            // Color based on amplitude
            int green = (int) (30 + (1 - normalizedAmp) * 50);
            wavePaint.setColor(Color.rgb(27, green, 32));

            canvas.drawLine(x, centerY - barHeight, x, centerY + barHeight, wavePaint);
        }
    }
}
