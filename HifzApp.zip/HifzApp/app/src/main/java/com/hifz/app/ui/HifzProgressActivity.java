package com.hifz.app.ui;

import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.hifz.app.R;
import com.hifz.app.data.Surah;
import java.util.ArrayList;
import java.util.List;

public class HifzProgressActivity extends AppCompatActivity {

    private HifzViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(0xFFF5F5F0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(root);

        MaterialToolbar toolbar = new MaterialToolbar(this);
        toolbar.setTitle("Hifz Progress");
        toolbar.setTitleTextColor(0xFFFFD700);
        toolbar.setBackgroundColor(0xFF1B5E20);
        toolbar.setNavigationIcon(R.drawable.ic_back);
        toolbar.setNavigationIconTint(0xFFFFFFFF);
        toolbar.setNavigationOnClickListener(v -> finish());
        root.addView(toolbar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Stats section
        LinearLayout statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        statsRow.setPadding(32, 32, 32, 16);

        TextView tvSurahCount = createStatCard("0", "Surahs\nMemorized", 0xFF1B5E20);
        TextView tvAyahCount = createStatCard("0", "Ayahs\nMemorized", 0xFFC9A84C);
        statsRow.addView(tvSurahCount, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        statsRow.addView(tvAyahCount, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        root.addView(statsRow);

        // Progress bar
        LinearProgressIndicator overallProgress = new LinearProgressIndicator(this);
        overallProgress.setMax(100);
        overallProgress.setProgress(0);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        progressParams.setMargins(32, 8, 32, 32);
        root.addView(overallProgress, progressParams);

        // Memorized Surahs list
        TextView tvTitle = new TextView(this);
        tvTitle.setText("Memorized Surahs");
        tvTitle.setTextSize(18);
        tvTitle.setTextColor(Color.parseColor("#1A1A1A"));
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setPadding(32, 0, 32, 16);
        root.addView(tvTitle);

        RecyclerView rvMemorized = new RecyclerView(this);
        rvMemorized.setLayoutManager(new LinearLayoutManager(this));
        rvMemorized.setNestedScrollingEnabled(false);
        root.addView(rvMemorized);

        setContentView(scrollView);

        viewModel = new ViewModelProvider(this).get(HifzViewModel.class);
        SurahAdapter adapter = new SurahAdapter(surah -> {});
        rvMemorized.setAdapter(adapter);

        viewModel.getMemorizedCount().observe(this, count -> {
            int c = count != null ? count : 0;
            tvSurahCount.setText(c + "\nSurahs\nMemorized");
            overallProgress.setProgress((c * 100) / 114);
        });

        viewModel.getTotalMemorizedAyahs().observe(this, ayahs -> {
            int a = ayahs != null ? ayahs : 0;
            tvAyahCount.setText(a + "\nAyahs\nMemorized");
        });

        viewModel.getAllSurahs().observe(this, surahs -> {
            List<Surah> memorized = new ArrayList<>();
            for (Surah s : surahs) {
                if (s.hifzStatus == 2) memorized.add(s);
            }
            adapter.submitList(memorized);
        });
    }

    private TextView createStatCard(String value, String label, int color) {
        TextView tv = new TextView(this);
        tv.setText(value + "\n" + label);
        tv.setTextSize(20);
        tv.setTextColor(color);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setPadding(16, 24, 16, 24);
        tv.setBackgroundColor(Color.WHITE);
        tv.setElevation(4);
        return tv;
    }
}
