package com.hifz.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(0xFF1B5E20);

        TextView tvArabic = new TextView(this);
        tvArabic.setText("حفظ القرآن");
        tvArabic.setTextSize(48);
        tvArabic.setTextColor(0xFFFFD700);
        tvArabic.setGravity(Gravity.CENTER);
        tvArabic.setTypeface(null, android.graphics.Typeface.BOLD);
        layout.addView(tvArabic);

        TextView tvSub = new TextView(this);
        tvSub.setText("Hifz Quran");
        tvSub.setTextSize(20);
        tvSub.setTextColor(0xCCFFFFFF);
        tvSub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = 16;
        tvSub.setLayoutParams(params);
        layout.addView(tvSub);

        TextView tvBism = new TextView(this);
        tvBism.setText("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ");
        tvBism.setTextSize(18);
        tvBism.setTextColor(0x99FFFFFF);
        tvBism.setGravity(Gravity.CENTER);
        tvBism.setPadding(32, 48, 32, 0);
        layout.addView(tvBism);

        setContentView(layout);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }, 2000);
    }
}
