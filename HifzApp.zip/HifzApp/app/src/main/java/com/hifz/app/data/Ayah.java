package com.hifz.app.data;

import androidx.room.Entity;
import androidx.room.ForeignKey;

@Entity(tableName = "ayahs",
        primaryKeys = {"surahNumber", "ayahNumber"},
        foreignKeys = @ForeignKey(entity = Surah.class,
                parentColumns = "number",
                childColumns = "surahNumber",
                onDelete = ForeignKey.CASCADE))
public class Ayah {
    public int surahNumber;
    public int ayahNumber;
    public String textArabic;
    public String textUthmani; // Uthmani script
    public String translation;
    public boolean isMemorized;
    public int mistakeCount;
    public long lastRecited;
    public int recitationCount;
    public int difficultyScore; // 0-100, higher = more mistakes

    public Ayah(int surahNumber, int ayahNumber, String textArabic,
                String textUthmani, String translation) {
        this.surahNumber = surahNumber;
        this.ayahNumber = ayahNumber;
        this.textArabic = textArabic;
        this.textUthmani = textUthmani;
        this.translation = translation;
        this.isMemorized = false;
        this.mistakeCount = 0;
        this.lastRecited = 0;
        this.recitationCount = 0;
        this.difficultyScore = 0;
    }
}
