package com.hifz.app.data;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import java.util.List;

@Dao
public interface AyahDao {

    @Query("SELECT * FROM ayahs WHERE surahNumber = :surahNumber ORDER BY ayahNumber")
    LiveData<List<Ayah>> getAyahsForSurah(int surahNumber);

    @Query("SELECT * FROM ayahs WHERE surahNumber = :surahNumber AND ayahNumber = :ayahNumber")
    Ayah getAyah(int surahNumber, int ayahNumber);

    @Query("SELECT * FROM ayahs WHERE difficultyScore > 50 ORDER BY difficultyScore DESC LIMIT 20")
    LiveData<List<Ayah>> getDifficultAyahs();

    @Query("SELECT COUNT(*) FROM ayahs WHERE surahNumber = :surahNumber AND isMemorized = 1")
    int getMemorizedCount(int surahNumber);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Ayah> ayahs);

    @Update
    void update(Ayah ayah);

    @Query("UPDATE ayahs SET isMemorized = :memorized WHERE surahNumber = :surahNumber AND ayahNumber = :ayahNumber")
    void setMemorized(int surahNumber, int ayahNumber, boolean memorized);

    @Query("UPDATE ayahs SET mistakeCount = mistakeCount + 1, difficultyScore = MIN(100, difficultyScore + 10) WHERE surahNumber = :surahNumber AND ayahNumber = :ayahNumber")
    void recordMistake(int surahNumber, int ayahNumber);

    @Query("UPDATE ayahs SET recitationCount = recitationCount + 1, lastRecited = :time, difficultyScore = MAX(0, difficultyScore - 5) WHERE surahNumber = :surahNumber AND ayahNumber = :ayahNumber")
    void recordCorrect(int surahNumber, int ayahNumber, long time);
}
