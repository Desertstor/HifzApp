package com.hifz.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "surahs")
public class Surah {
    @PrimaryKey
    public int number;
    public String nameArabic;
    public String nameEnglish;
    public String nameTransliteration;
    public int ayahCount;
    public String revelationType; // Meccan / Medinan
    public int hifzStatus; // 0=not started, 1=in progress, 2=memorized
    public int memorizedAyahs;
    public long lastPracticed;
    public int practiceCount;

    public Surah(int number, String nameArabic, String nameEnglish,
                 String nameTransliteration, int ayahCount, String revelationType) {
        this.number = number;
        this.nameArabic = nameArabic;
        this.nameEnglish = nameEnglish;
        this.nameTransliteration = nameTransliteration;
        this.ayahCount = ayahCount;
        this.revelationType = revelationType;
        this.hifzStatus = 0;
        this.memorizedAyahs = 0;
        this.lastPracticed = 0;
        this.practiceCount = 0;
    }

    public float getProgressPercent() {
        if (ayahCount == 0) return 0;
        return (memorizedAyahs * 100f) / ayahCount;
    }

    public String getStatusLabel() {
        switch (hifzStatus) {
            case 2: return "Memorized";
            case 1: return "In Progress";
            default: return "Not Started";
        }
    }
}
