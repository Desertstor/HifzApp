package com.hifz.app.api;

import android.util.Log;
import okhttp3.*;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class TarteelApiClient {

    private static final String TAG = "TarteelApiClient";
    private static final String BASE_URL = "https://api.tarteel.ai/v1/";
    private static final String QURAN_API_URL = "https://api.alquran.cloud/v1/";

    private final OkHttpClient client;
    private String apiKey;

    public interface RecognitionCallback {
        void onResult(RecognitionResult result);
        void onError(String error);
    }

    public interface QuranTextCallback {
        void onResult(String arabicText, String translation);
        void onError(String error);
    }

    public static class RecognitionResult {
        public int surahNumber;
        public int ayahNumber;
        public String surahName;
        public String arabicText;
        public float confidence;
        public boolean isCorrect;

        public RecognitionResult(int surahNumber, int ayahNumber,
                                  String surahName, String arabicText, float confidence) {
            this.surahNumber = surahNumber;
            this.ayahNumber = ayahNumber;
            this.surahName = surahName;
            this.arabicText = arabicText;
            this.confidence = confidence;
            this.isCorrect = confidence > 0.7f;
        }
    }

    public TarteelApiClient(String apiKey) {
        this.apiKey = apiKey;
        this.client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    /**
     * Send audio file to Tarteel API for Quran recognition.
     * Tarteel API: POST /recognize with audio file
     */
    public void recognizeRecitation(File audioFile, int expectedSurah,
                                     int expectedAyah, RecognitionCallback callback) {
        if (apiKey == null || apiKey.isEmpty()) {
            // Fallback: use free AlQuran.cloud API to get text, skip recognition
            fetchAyahText(expectedSurah, expectedAyah, new QuranTextCallback() {
                @Override
                public void onResult(String arabicText, String translation) {
                    callback.onResult(new RecognitionResult(
                            expectedSurah, expectedAyah, "", arabicText, 1.0f));
                }
                @Override
                public void onError(String error) {
                    callback.onError(error);
                }
            });
            return;
        }

        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("audio", audioFile.getName(),
                        RequestBody.create(audioFile, MediaType.parse("audio/wav")))
                .addFormDataPart("surah", String.valueOf(expectedSurah))
                .addFormDataPart("ayah", String.valueOf(expectedAyah))
                .build();

        Request request = new Request.Builder()
                .url(BASE_URL + "recognize")
                .addHeader("Authorization", "Token " + apiKey)
                .post(requestBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "API call failed: " + e.getMessage());
                callback.onError(e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    callback.onError("API error: " + response.code());
                    return;
                }
                try {
                    String body = response.body().string();
                    JSONObject json = new JSONObject(body);
                    int surah = json.optInt("surah_number", expectedSurah);
                    int ayah = json.optInt("ayah_number", expectedAyah);
                    float confidence = (float) json.optDouble("confidence", 0.8);
                    String text = json.optString("arabic_text", "");
                    String surahName = json.optString("surah_name", "");

                    callback.onResult(new RecognitionResult(
                            surah, ayah, surahName, text, confidence));

                } catch (JSONException e) {
                    callback.onError("Parse error: " + e.getMessage());
                }
            }
        });
    }

    /**
     * Fetch ayah text from free AlQuran.cloud API
     */
    public void fetchAyahText(int surahNumber, int ayahNumber, QuranTextCallback callback) {
        String url = QURAN_API_URL + "ayah/" + surahNumber + ":" + ayahNumber + "/editions/quran-uthmani,en.asad";

        Request request = new Request.Builder().url(url).get().build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onError(e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    callback.onError("HTTP " + response.code());
                    return;
                }
                try {
                    JSONObject json = new JSONObject(response.body().string());
                    JSONObject data = json.getJSONArray("data").getJSONObject(0);
                    String arabic = data.getString("text");

                    String translation = "";
                    try {
                        translation = json.getJSONArray("data")
                                .getJSONObject(1).getString("text");
                    } catch (Exception ignored) {}

                    callback.onResult(arabic, translation);
                } catch (JSONException e) {
                    callback.onError("Parse error: " + e.getMessage());
                }
            }
        });
    }

    /**
     * Fetch all ayahs for a surah
     */
    public void fetchSurahAyahs(int surahNumber, QuranTextCallback callback) {
        String url = QURAN_API_URL + "surah/" + surahNumber + "/quran-uthmani";
        Request request = new Request.Builder().url(url).get().build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onError(e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    callback.onError("HTTP " + response.code());
                    return;
                }
                try {
                    String body = response.body().string();
                    callback.onResult(body, "");
                } catch (Exception e) {
                    callback.onError(e.getMessage());
                }
            }
        });
    }

    public void setApiKey(String key) {
        this.apiKey = key;
    }
}
