package com.hifz.app.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import com.google.android.material.snackbar.Snackbar;
import com.hifz.app.api.TarteelApiClient;
import com.hifz.app.data.Ayah;
import com.hifz.app.databinding.ActivityRecitationBinding;
import com.hifz.app.utils.AudioRecorder;
import java.io.File;
import java.util.List;

public class RecitationActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST = 100;
    private ActivityRecitationBinding binding;
    private HifzViewModel viewModel;
    private TarteelApiClient apiClient;
    private AudioRecorder audioRecorder;

    private int surahNumber;
    private int currentAyahIndex = 0;
    private List<Ayah> ayahs;
    private boolean isRecording = false;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRecitationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        surahNumber = getIntent().getIntExtra("surah_number", 1);
        viewModel = new ViewModelProvider(this).get(HifzViewModel.class);

        String apiKey = getSharedPreferences("hifz_prefs", MODE_PRIVATE)
                .getString("tarteel_api_key", "");
        apiClient = new TarteelApiClient(apiKey);

        setupToolbar();
        loadSurahData();
        setupClickListeners();
    }

    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void loadSurahData() {
        viewModel.getSurah(surahNumber).observe(this, surah -> {
            if (surah != null) {
                binding.toolbar.setTitle(surah.nameTransliteration);
                binding.tvSurahName.setText(surah.nameArabic);
            }
        });

        viewModel.getAyahsForSurah(surahNumber).observe(this, list -> {
            if (list != null && !list.isEmpty()) {
                ayahs = list;
                displayCurrentAyah();
            } else {
                // Fetch from API if not in DB
                fetchAyahsFromApi();
            }
        });
    }

    private void fetchAyahsFromApi() {
        binding.tvStatus.setText("Loading ayahs...");
        apiClient.fetchAyahText(surahNumber, 1, new TarteelApiClient.QuranTextCallback() {
            @Override
            public void onResult(String arabicText, String translation) {
                mainHandler.post(() -> {
                    binding.tvAyahArabic.setText(arabicText);
                    binding.tvAyahTranslation.setText(translation);
                    binding.tvStatus.setText(getString(com.hifz.app.R.string.tap_to_start));
                });
            }
            @Override
            public void onError(String error) {
                mainHandler.post(() -> binding.tvStatus.setText("Error: " + error));
            }
        });
    }

    private void displayCurrentAyah() {
        if (ayahs == null || currentAyahIndex >= ayahs.size()) return;

        Ayah ayah = ayahs.get(currentAyahIndex);
        binding.tvAyahNumber.setText(String.valueOf(ayah.ayahNumber));
        binding.tvAyahArabic.setText(ayah.textUthmani != null ? ayah.textUthmani : ayah.textArabic);
        binding.tvAyahTranslation.setText(ayah.translation);
        binding.tvAyahCounter.setText("Ayah " + ayah.ayahNumber + " of " +
                (ayahs != null ? ayahs.size() : "?"));

        // Update memorized button
        boolean isMemorized = ayah.isMemorized;
        binding.btnMarkMemorized.setText(isMemorized ? "✓ Memorized" : "Mark as Memorized");
        binding.btnMarkMemorized.setStrokeColor(
                android.content.res.ColorStateList.valueOf(
                        isMemorized ? Color.parseColor("#2E7D32") : Color.GRAY));

        binding.cardResult.setVisibility(View.GONE);
    }

    private void setupClickListeners() {
        binding.fabMic.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST);
                return;
            }
            toggleRecording();
        });

        binding.btnNext.setOnClickListener(v -> {
            if (ayahs != null && currentAyahIndex < ayahs.size() - 1) {
                currentAyahIndex++;
                displayCurrentAyah();
            }
        });

        binding.btnPrev.setOnClickListener(v -> {
            if (currentAyahIndex > 0) {
                currentAyahIndex--;
                displayCurrentAyah();
            }
        });

        binding.btnMarkMemorized.setOnClickListener(v -> {
            if (ayahs == null) return;
            Ayah ayah = ayahs.get(currentAyahIndex);
            boolean newStatus = !ayah.isMemorized;
            viewModel.setAyahMemorized(surahNumber, ayah.ayahNumber, newStatus);
            Snackbar.make(binding.getRoot(),
                    newStatus ? "Ayah marked as memorized! ✓" : "Ayah unmarked",
                    Snackbar.LENGTH_SHORT).show();
        });
    }

    private void toggleRecording() {
        if (isRecording) {
            stopRecording();
        } else {
            startRecording();
        }
    }

    private void startRecording() {
        isRecording = true;
        binding.fabMic.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(Color.RED));
        binding.tvStatus.setText("● Listening...");
        binding.waveformView.startAnimation();

        File audioFile = new File(getCacheDir(), "recitation.wav");
        audioRecorder = new AudioRecorder(audioFile, new AudioRecorder.RecordingCallback() {
            @Override
            public void onAmplitudeChanged(int amplitude) {
                mainHandler.post(() -> binding.waveformView.updateAmplitude(amplitude));
            }

            @Override
            public void onRecordingComplete(File file) {
                mainHandler.post(() -> sendToApi(file));
            }

            @Override
            public void onError(String error) {
                mainHandler.post(() -> {
                    isRecording = false;
                    resetMicButton();
                    binding.tvStatus.setText("Error: " + error);
                });
            }
        });
        audioRecorder.startRecording();
    }

    private void stopRecording() {
        if (audioRecorder != null) {
            audioRecorder.stopRecording();
        }
        isRecording = false;
        resetMicButton();
        binding.tvStatus.setText("Processing...");
        binding.waveformView.stopAnimation();
    }

    private void resetMicButton() {
        binding.fabMic.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(
                        ContextCompat.getColor(this, com.hifz.app.R.color.primary)));
    }

    private void sendToApi(File audioFile) {
        if (ayahs == null || currentAyahIndex >= ayahs.size()) return;
        Ayah currentAyah = ayahs.get(currentAyahIndex);

        apiClient.recognizeRecitation(audioFile, surahNumber, currentAyah.ayahNumber,
                new TarteelApiClient.RecognitionCallback() {
                    @Override
                    public void onResult(TarteelApiClient.RecognitionResult result) {
                        mainHandler.post(() -> showResult(result, currentAyah));
                    }

                    @Override
                    public void onError(String error) {
                        mainHandler.post(() -> {
                            binding.tvStatus.setText("Error: " + error);
                        });
                    }
                });
    }

    private void showResult(TarteelApiClient.RecognitionResult result, Ayah ayah) {
        binding.cardResult.setVisibility(View.VISIBLE);
        int percent = (int) (result.confidence * 100);
        binding.progressConfidence.setProgress(percent);
        binding.tvConfidenceLabel.setText("Confidence: " + percent + "%");

        if (result.isCorrect) {
            binding.tvResultTitle.setText("✓ Correct! Well done");
            binding.tvResultTitle.setTextColor(Color.parseColor("#2E7D32"));
            binding.progressConfidence.setIndicatorColor(
                    new int[]{Color.parseColor("#4CAF50")});
            binding.tvAyahArabic.setBackgroundColor(Color.parseColor("#C8E6C9"));
            viewModel.recordCorrectRecitation(surahNumber, ayah.ayahNumber);
            binding.tvStatus.setText("Ayah recognized correctly");

            // Auto advance after 2 seconds
            mainHandler.postDelayed(() -> {
                binding.tvAyahArabic.setBackgroundColor(Color.TRANSPARENT);
                if (ayahs != null && currentAyahIndex < ayahs.size() - 1) {
                    currentAyahIndex++;
                    displayCurrentAyah();
                }
            }, 2000);

        } else {
            binding.tvResultTitle.setText("✗ Try again");
            binding.tvResultTitle.setTextColor(Color.parseColor("#D32F2F"));
            binding.progressConfidence.setIndicatorColor(
                    new int[]{Color.parseColor("#FF5722")});
            binding.tvAyahArabic.setBackgroundColor(Color.parseColor("#FFCDD2"));
            viewModel.recordMistake(surahNumber, ayah.ayahNumber);
            binding.tvStatus.setText("Keep practicing - tap mic to try again");

            mainHandler.postDelayed(() ->
                    binding.tvAyahArabic.setBackgroundColor(Color.TRANSPARENT), 2000);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == PERMISSION_REQUEST && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) {
            toggleRecording();
        } else {
            Snackbar.make(binding.getRoot(),
                    getString(com.hifz.app.R.string.permission_required),
                    Snackbar.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (audioRecorder != null && audioRecorder.isRecording()) {
            audioRecorder.stopRecording();
        }
    }
}
