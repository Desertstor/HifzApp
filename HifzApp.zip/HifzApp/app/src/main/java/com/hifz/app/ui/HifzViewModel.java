package com.hifz.app.ui;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.hifz.app.data.*;
import java.util.List;

public class HifzViewModel extends AndroidViewModel {

    private final HifzRepository repository;

    public HifzViewModel(Application application) {
        super(application);
        repository = new HifzRepository(application);
    }

    public LiveData<List<Surah>> getAllSurahs() {
        return repository.getAllSurahs();
    }

    public LiveData<List<Surah>> getInProgressSurahs() {
        return repository.getInProgressSurahs();
    }

    public LiveData<Integer> getMemorizedCount() {
        return repository.getMemorizedCount();
    }

    public LiveData<Integer> getTotalMemorizedAyahs() {
        return repository.getTotalMemorizedAyahs();
    }

    public LiveData<Surah> getSurah(int number) {
        return repository.getSurah(number);
    }

    public LiveData<List<Ayah>> getAyahsForSurah(int surahNumber) {
        return repository.getAyahsForSurah(surahNumber);
    }

    public LiveData<List<Ayah>> getDifficultAyahs() {
        return repository.getDifficultAyahs();
    }

    public void updateSurahStatus(int number, int status) {
        repository.updateSurahStatus(number, status);
    }

    public void recordCorrectRecitation(int surahNumber, int ayahNumber) {
        repository.recordCorrectRecitation(surahNumber, ayahNumber);
    }

    public void recordMistake(int surahNumber, int ayahNumber) {
        repository.recordMistake(surahNumber, ayahNumber);
    }

    public void setAyahMemorized(int surahNumber, int ayahNumber, boolean memorized) {
        repository.setAyahMemorized(surahNumber, ayahNumber, memorized);
    }
}
