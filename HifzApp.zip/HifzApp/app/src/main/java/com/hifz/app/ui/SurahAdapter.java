package com.hifz.app.ui;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.hifz.app.R;
import com.hifz.app.data.Surah;

public class SurahAdapter extends ListAdapter<Surah, SurahAdapter.ViewHolder> {

    public interface OnSurahClickListener {
        void onClick(Surah surah);
    }

    private final OnSurahClickListener listener;

    public SurahAdapter(OnSurahClickListener listener) {
        super(DIFF_CALLBACK);
        this.listener = listener;
    }

    private static final DiffUtil.ItemCallback<Surah> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<Surah>() {
                @Override
                public boolean areItemsTheSame(@NonNull Surah a, @NonNull Surah b) {
                    return a.number == b.number;
                }

                @Override
                public boolean areContentsTheSame(@NonNull Surah a, @NonNull Surah b) {
                    return a.hifzStatus == b.hifzStatus &&
                            a.memorizedAyahs == b.memorizedAyahs;
                }
            };

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_surah, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Surah surah = getItem(position);
        holder.bind(surah);
        holder.itemView.setOnClickListener(v -> listener.onClick(surah));
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNumber, tvNameArabic, tvNameEnglish, tvAyahCount, tvStatusBadge;
        LinearProgressIndicator progressMemorized;

        ViewHolder(View view) {
            super(view);
            tvNumber = view.findViewById(R.id.tvNumber);
            tvNameArabic = view.findViewById(R.id.tvNameArabic);
            tvNameEnglish = view.findViewById(R.id.tvNameEnglish);
            tvAyahCount = view.findViewById(R.id.tvAyahCount);
            tvStatusBadge = view.findViewById(R.id.tvStatusBadge);
            progressMemorized = view.findViewById(R.id.progressMemorized);
        }

        void bind(Surah surah) {
            tvNumber.setText(String.valueOf(surah.number));
            tvNameArabic.setText(surah.nameArabic);
            tvNameEnglish.setText(surah.nameTransliteration + " • " + surah.ayahCount + " ayahs");
            tvAyahCount.setText(surah.memorizedAyahs + "/" + surah.ayahCount);

            int progress = (int) surah.getProgressPercent();
            progressMemorized.setProgress(progress);

            // Status badge
            tvStatusBadge.setText(surah.getStatusLabel());
            int badgeColor;
            switch (surah.hifzStatus) {
                case 2:
                    badgeColor = Color.parseColor("#2E7D32");
                    break;
                case 1:
                    badgeColor = Color.parseColor("#F57C00");
                    break;
                default:
                    badgeColor = Color.parseColor("#9E9E9E");
                    break;
            }
            tvStatusBadge.setBackgroundColor(badgeColor);
        }
    }
}
