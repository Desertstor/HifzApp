# Hifz Quran App

A Tarteel-inspired Android app for Quran memorization tracking with speech recognition.

## Features
- 📖 Full 114 Surah list with Arabic names
- 🎙️ Audio recording with waveform visualizer
- 🤖 Tarteel API integration for Quran recognition
- 📊 Hifz progress tracking per surah & ayah
- ✅ Mark ayahs as memorized
- 🔍 Search surahs by name or number
- 💾 Local Room database for offline progress tracking
- 📈 Overall Quran memorization percentage

## Setup

### 1. Add Amiri Font
- Download `Amiri-Regular.ttf` from https://fonts.google.com/specimen/Amiri
- Place it at: `app/src/main/res/font/amiri.ttf`

### 2. Add Tarteel API Key (Optional)
- Sign up at https://tarteel.ai for an API key
- In the app: Settings → Enter your Tarteel API key
- Without a key: the app fetches Quran text from AlQuran.cloud (free) but skips audio recognition

### 3. Build in Android Studio
- Open the `HifzApp` folder in Android Studio
- Sync Gradle
- Run on a device or emulator (API 24+)

## Architecture
- **Language**: Java
- **Database**: Room (SQLite)
- **Networking**: OkHttp
- **UI**: Material Design 3
- **Pattern**: MVVM (ViewModel + LiveData)
- **API**: Tarteel API + AlQuran.cloud (free fallback)

## How It Works
1. Select a surah from the list
2. Tap the microphone button and recite
3. The audio is sent to Tarteel API for recognition
4. If correct → ayah highlighted green, auto-advances
5. If incorrect → highlighted red, try again
6. Mark ayahs as memorized manually or via recognition
7. Track progress in the Hifz Progress screen

## Screens
- **Splash**: Islamic greeting with بسم الله
- **Main**: Stats dashboard + in-progress surahs
- **Surah List**: All 114 surahs with search
- **Recitation**: Core screen with mic + ayah display
- **Hifz Progress**: Overall memorization stats

## API Details
- **Tarteel API**: `POST https://api.tarteel.ai/v1/recognize`
  - Auth: `Authorization: Token YOUR_KEY`
  - Body: multipart/form-data with audio file + surah + ayah numbers
- **AlQuran.cloud** (free fallback): `GET https://api.alquran.cloud/v1/ayah/{surah}:{ayah}/editions/quran-uthmani,en.asad`
